"""Write the human-readable verification report from actual machine-readable test outputs."""
import json,gzip
from pathlib import Path
R=Path(__file__).resolve().parents[1];a=json.loads((R/'reports/assets.json').read_text());b=json.loads((R/'reports/browser.json').read_text());m=json.loads((R/'metadata/tool.json').read_text())
rows=[]
for x in a['results']:
 v=m['noseRadiusVariants'][x['variant']];rows.append(f"| {x['variant']} | {x['bytes']:,} | {x['triangles']} | {x['measuredIncludedAngleDegrees']:.6f}° | {x['tipVertexErrorMm']:.9f} | {x['bboxMaxErrorMm']:.9f} |")
text='''# 模型验证报告

## 实际完成情况

模型库计数为1把刀，包含3个真实鼻圆几何变体。保留原模型、原.blend、参数化脚本和原预览器；没有重建G代码引擎、没有接入微信或生产项目。本轮没有Git提交、推送或部署。

标准化脚本已成功导出3份GLB：从原装配烘焙到新安装原点，未做有损减面。文件存在、GLB2头/长度/JSON/BIN可解析、SHA-256与元数据一致。独立Python脚本读取实际GLB的节点变换与顶点，而非只信任JSON。

| 版本 | GLB字节 | 三角面 | 导出直边实测尖角 | 刀尖误差mm | 包围盒误差mm |
|---|---:|---:|---:|---:|---:|
'''+ '\n'.join(rows)+f'''

3份GLB总计 **{a['totalModelBytes']:,} 字节（{a['totalModelBytes']/1024/1024:.3f} MiB）**。每份5个实体网格、4个材质、0纹理。所测圆弧侧壁顶点分别吻合R0.2/R0.4/R0.8，最大圆弧半径离散误差小于0.000011mm。三个版本的刀尖及圆弧中心均不同，没有复用同一刀尖坐标。GLB浮点误差是数字导出误差，不是制造精度。

源网格检查：三版所有部件0非流形边、正有向体积、有限法线；GLB顶点和法线有限、法线长度约1，未检出退化三角形。刀杆/刀片、刀杆/螺丝头、刀杆/螺丝轴、垫座/螺丝头及轴、刀片/螺丝头及轴的所选BVH表面求交为0。座腔底面与垫座、垫座与刀片的设计共面接触单独保留，不能误报为穿透。

这些是网格和所选表面的检查，不是任意实体体积求交、连续扫掠或实际支承承载认证。模型背面、隐藏夹紧结构及公差仍需专业人工复核。

## Three.js接口验证

实际GLTFLoader加载三版，恢复mm/Z-up后包围盒及刀尖与元数据一致。世界刀尖在非单位父级、平移和旋转装配后的误差为{b['interfaces']['worldTipError']:.3g}mm。已断言：

- 同版本两个实例资源独立，释放一个不会影响另一个；释放回调覆盖5份几何且重复释放安全。
- 同版本并发加载仅发1次GLB字节请求；清空缓存后字节缓存计数为0。
- 未知toolId拒绝；安装点为(0,0,0)。
- 更换r02→r08后保留装配矩阵并更新几何及元数据。
- 实体部件查询不包含坐标轴、标记球或UI包围盒，便于未来碰撞模块挂接。
- 预览器部件显隐、装配变换、四方向与完整模型视图均已检查并截图。
- 页面JavaScript错误0，所记录HTTP错误0。

## 手机及微信边界

已验证云端Chromium 390×844移动视口，真实CDP触摸事件可以旋转视角，无水平溢出。轻量材质活动旋转实测约{b['cloudActiveRotationFps']:.1f} FPS，该值受本次云端环境影响，不是手机性能承诺。

普通实体手机浏览器 **未真机验证**；微信原生WebGL **未适配或真机验证**；微信Web-view **未真机验证**。后两者还需要正式项目的canvas/IO适配、业务域名、宿主Three版本和iOS/Android生命周期实测，不能把移动视口测试写成微信真机通过。

## 性能处理

5个实体网格与约8400三角面保留座腔、通孔、驱动槽和刀尖圆弧，不为压缩体积破坏刃口几何。无纹理、无动画/灯光/摄像机、无Draco运行时，原来的单位换算空父节点已经烘焙移除；模块按需只加载选中版本。

静止按需渲染，移动视口默认轻量材质；切换回PBR不会改动GLB。每版正确HTTP gzip传输约131KiB，未引入额外压缩解码依赖。原始字节缓存最多3个已知版本、总约1.51MiB；实际几何实例需由宿主按生命周期释放。

## 机械人工审核清单

准确产品型号与制造商图纸、全部实际线性尺寸/鼻圆/刃口公差、主偏角、手向、刀片安装姿态与真实刀座基准、后角、垫座支承、螺丝与螺纹、材质牌号和涂层。35°来自任务和参考标签并由程序构造，不代表厂家认证。当前尺寸全部为教学近似，未从透视图推测真实尺寸。

原脚本中R同时影响刀片、配套座腔与刀头前端，三个版本的刀杆长度也不同；数据已按实记录。正式产品若要求同一刀杆可互换多种R角，需要厂家座腔图与完整安装验证。

参考图再分发授权未确认，包内仅保存来源和哈希，原工作区图片保持不变。

## 复现

见docs/integration.md。实际自动化输出为reports/assets.json和reports/browser.json；不是仅设计的测试计划。后续修改GLB、元数据或模块后必须重新运行相关检查。
'''
if (R/'reports/relocation.json').exists():
 text+='\n## ZIP独立性验收\n\n已在独立临时目录解压测试包，逐文件核对清单哈希，通过新的HTTP源加载三版GLB，页面错误为0。报告见reports/relocation.json。资源不依赖原工作区绝对路径；参考原图未作为运行时依赖。\n'
(R/'docs/verification.md').write_text(text)
